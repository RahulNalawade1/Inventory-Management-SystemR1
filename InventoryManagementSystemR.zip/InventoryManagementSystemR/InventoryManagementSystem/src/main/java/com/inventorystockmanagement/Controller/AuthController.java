package com.inventorystockmanagement.Controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.inventorystockmanagement.Dtos.BaseResponseDTO;
import com.inventorystockmanagement.Dtos.LoginRequestDTO;
import com.inventorystockmanagement.Dtos.LoginResponseDTO;
import com.inventorystockmanagement.Dtos.RegisterRequestDTO;
import com.inventorystockmanagement.Services.UserService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

    private final UserService userService;

    @PostMapping("/register")
    public ResponseEntity<BaseResponseDTO<?>> registerUser(@Valid @RequestBody RegisterRequestDTO registerRequest) {
        try {
            return ResponseEntity.ok(BaseResponseDTO.success("User registered successfully",
                    userService.registerUser(registerRequest)));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(BaseResponseDTO.error(e.getMessage()));
        }
    }

    @PostMapping("/login")
    public ResponseEntity<BaseResponseDTO<?>> authenticateUser(@Valid @RequestBody LoginRequestDTO loginRequest) {
        try {
            LoginResponseDTO loginResponse = userService.loginUser(loginRequest);
            return ResponseEntity.ok(BaseResponseDTO.success("Login successful", loginResponse));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(BaseResponseDTO.error(e.getMessage()));
        }
    }
    
}