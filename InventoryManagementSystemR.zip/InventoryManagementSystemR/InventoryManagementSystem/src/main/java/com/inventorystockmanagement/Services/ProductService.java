package com.inventorystockmanagement.Services;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.inventorystockmanagement.Dtos.ProductDTO;
import com.inventorystockmanagement.Dtos.StockUpdateDTO;

import java.math.BigDecimal;
import java.util.List;

public interface ProductService {

    ProductDTO createProduct(ProductDTO productDTO);
    ProductDTO getProductById(Long id);
    Page<ProductDTO> getAllProducts(Pageable pageable);
    Page<ProductDTO> getProductsByCategory(String category, Pageable pageable);
    Page<ProductDTO> getProductsByBrand(String brand, Pageable pageable);
    Page<ProductDTO> getProductsByPriceRange(BigDecimal minPrice,BigDecimal maxPrice, Pageable pageable);
    Page<ProductDTO> searchProducts(String name, Pageable pageable);
    ProductDTO updateProduct(Long id, ProductDTO productDTO);
    void deleteProduct(Long id);
    ProductDTO updateStock(Long id, StockUpdateDTO stockUpdateDTo, Long userId);
    List<ProductDTO> getLowStockProducts();
}
