package com.inventorystockmanagement.Services;

import com.inventorystockmanagement.Entities.*;
import com.inventorystockmanagement.Enums.UserStatus;
import com.inventorystockmanagement.Repositories.*;
import com.inventorystockmanagement.Security.JwtTokenProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.inventorystockmanagement.Dtos.LoginRequestDTO;
import com.inventorystockmanagement.Dtos.LoginResponseDTO;
import com.inventorystockmanagement.Dtos.RegisterRequestDTO;
import com.inventorystockmanagement.Dtos.UserDTO;
import com.inventorystockmanagement.Exceptions.ResourceNotFoundException;
import com.inventorystockmanagement.Mapper.UserMapper;
import com.inventorystockmanagement.Security.JwtUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final AdminRepository adminRepository;
    private final DealerRepository dealerRepository;
    private final CustomerRepository customerRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtUtils jwtUtils;
    private final UserMapper userMapper;
    private final JwtTokenProvider jwtTokenProvider;
    private final RoleRepository roleRepository;

    @Override
    @Transactional
    public UserDTO registerUser(RegisterRequestDTO registerRequest) {
        if (userRepository.existsByEmail(registerRequest.getEmail())) {
            throw new RuntimeException("Error: Email is already in use!");
        }

        User user = new User();
        user.setName(registerRequest.getName());
        user.setEmail(registerRequest.getEmail());
        user.setPassword(passwordEncoder.encode(registerRequest.getPassword()));
        user.setRole(registerRequest.getRole());
        user.setMobileNo(registerRequest.getMobileNo());
        user.setAddress(registerRequest.getAddress());
        user.setStatus(UserStatus.ACTIVE);
        user.setCreatedAt(LocalDateTime.now());

        User savedUser = userRepository.save(user);


        switch (registerRequest.getRole().toUpperCase()) {
            case "ADMIN":
                createAdmin(savedUser, registerRequest);
                break;
            case "DEALER":
                createDealer(savedUser, registerRequest);
                break;
            case "CUSTOMER":
                createCustomer(savedUser, registerRequest);
                break;
            default:
                throw new RuntimeException("Error: Invalid role specified!");
        }

        return userMapper.toDTO(savedUser);
    }

    private void createAdmin(User user, RegisterRequestDTO request) {
        Admin admin = new Admin();
        admin.setUser(user);
        admin.setAdminCode(request.getAdminCode() != null ? request.getAdminCode() : generateAdminCode());
        adminRepository.save(admin);

        Role role = new Role();
        role.setName(Role.ERole.ROLE_ADMIN);
        role.setUser(user);
        roleRepository.save(role);

        user.getRoles().add(role);
    }


    private void createDealer(User user, RegisterRequestDTO request) {
        Dealer dealer = new Dealer();
        dealer.setUser(user);
        dealer.setDealerCode(request.getDealerCode() != null ? request.getDealerCode() : generateDealerCode());
        dealer.setBusinessName(request.getBusinessName());
        dealer.setTaxNumber(request.getTaxNumber());
        dealer.setBusinessAddress(request.getBusinessAddress());
        dealer.setRegistrationDate(LocalDateTime.now());
        dealer.setStatus("ACTIVE");
        dealerRepository.save(dealer);

        Role role = new Role();
        role.setName(Role.ERole.ROLE_DEALER);
        role.setUser(user);
        roleRepository.save(role);

        user.getRoles().add(role);
    }

    private void createCustomer(User user, RegisterRequestDTO request) {
        Customer customer = new Customer();
        customer.setUser(user);
        customer.setCustomerCode(request.getCustomerCode() != null ? request.getCustomerCode() : generateCustomerCode());
        customer.setDateOfBirth(parseDateOfBirth(request.getDateOfBirth()));
        customer.setPreferredPaymentMethod(request.getPreferredPaymentMethod());
        customer.setShippingAddress(request.getShippingAddress());
        customerRepository.save(customer);

        Role role = new Role();
        role.setName(Role.ERole.ROLE_CUSTOMER);
        role.setUser(user);
        roleRepository.save(role);

        user.getRoles().add(role);
    }

    private LocalDate parseDateOfBirth(String dateOfBirth) {
        if (dateOfBirth == null || dateOfBirth.isBlank()) {
            return null;}
            try {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                return LocalDate.parse(dateOfBirth, formatter);
            } catch (Exception e) {
                return null;
            }
    }
    private String generateAdminCode() {
        return "ADM" + System.currentTimeMillis();
    }

    private String generateDealerCode() {
        return "DLR" + System.currentTimeMillis();
    }

    private String generateCustomerCode() {
        return "CUST" + System.currentTimeMillis();
    }

    @Override
    public Page<UserDTO> getAllUsers(Pageable pageable) {
        Page<User> users = userRepository.findAll(pageable);
        return users.map(userMapper::toDTO);
    }

    @Override
    public LoginResponseDTO loginUser(LoginRequestDTO loginRequest) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        loginRequest.getEmail(),
                        loginRequest.getPassword())
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);

        User user = (User) authentication.getPrincipal();

        String token = jwtTokenProvider.generateToken(authentication);

        UserDTO userDTO = userMapper.toDTO(user);

        LoginResponseDTO loginResponse = new LoginResponseDTO();
        loginResponse.setToken(token);
        loginResponse.setUser(userDTO);

        return loginResponse;
    }

    @Override
    public UserDTO getUserById(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
        return userMapper.toDTO(user);
    }

    @Override
    public UserDTO getUserByEmail(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email));
        return userMapper.toDTO(user);
    }

    @Override
    public User getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

    }

    @Override
    public UserDTO getCurrentUserDTO() {
        return userMapper.toDTO(getCurrentUser());
    }

    @Override
    public UserDTO updateUserProfile(long id, UserDTO userDTO) {
        return null;
    }

    @Override
    public void deleteUser(Long id) {

    }

    @Override
    public Page<UserDTO> searchUsers(String keyword, Pageable pageable) {
        return null;
    }

    @Override
    public Page<UserDTO> getUsersByRole(String role, Pageable pageable) {
        return null;
    }

}
