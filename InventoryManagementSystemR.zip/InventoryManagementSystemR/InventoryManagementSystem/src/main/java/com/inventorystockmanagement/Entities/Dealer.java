package com.inventorystockmanagement.Entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "dealers")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Dealer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(name = "dealer_code", unique = true)
    private String dealerCode;

    @Column(name = "business_name")
    private String businessName;

  @Column(name = "tax_number")
    private String taxNumber;

    @Column(name = "business_address")
    private String businessAddress;

    @Column(name = "registration_date")
    private LocalDateTime registrationDate;

    private String status = "ACTIVE";

}