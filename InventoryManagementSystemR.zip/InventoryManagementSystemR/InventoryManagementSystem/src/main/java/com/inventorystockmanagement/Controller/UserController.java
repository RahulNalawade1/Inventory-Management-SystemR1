package com.inventorystockmanagement.Controller;

import com.inventorystockmanagement.Dtos.BaseResponseDTO;
import com.inventorystockmanagement.Dtos.RegisterRequestDTO;
import com.inventorystockmanagement.Dtos.UserDTO;
import com.inventorystockmanagement.Enums.UserStatus;
import com.inventorystockmanagement.Services.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<BaseResponseDTO<UserDTO>> createUser(@Valid @RequestBody
                                                               RegisterRequestDTO registerRequestDTO) {
        UserDTO userDTO = userService.registerUser(registerRequestDTO);
        return ResponseEntity.ok(BaseResponseDTO.success("User Created Successfully", userDTO));
    }


    @GetMapping("/me")
    public ResponseEntity<BaseResponseDTO<UserDTO>> getCurrentUser() {
        UserDTO userDTO = userService.getCurrentUserDTO();
        return ResponseEntity.ok(BaseResponseDTO.success(userDTO));
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public  ResponseEntity<BaseResponseDTO<Page<UserDTO>>> getAllUsers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "15") int size,
            @RequestParam(defaultValue = "name") String sortBy) {

        Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy));
        Page<UserDTO> users = Page.empty(pageable);
        return ResponseEntity.ok(BaseResponseDTO.success(users));
    }


    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<BaseResponseDTO<UserDTO>> getUserById(@PathVariable Long id) {
        UserDTO currentUser = userService.getCurrentUserDTO();
        return ResponseEntity.ok(BaseResponseDTO.success(currentUser));
    }

    @GetMapping("/{id}/status")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<BaseResponseDTO<UserDTO>> updateUserStatus(
            @PathVariable long id,
            @RequestParam UserStatus status) {
        UserDTO currentUser = userService.getCurrentUserDTO();
        return ResponseEntity.ok(BaseResponseDTO.success("User Status Updated to " + status, currentUser));
    }


    @PutMapping("/{id}/role")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<BaseResponseDTO<UserDTO>> updateUserRole(
            @PathVariable long id,
            @RequestParam String role) {
        UserDTO currentUser = userService.getCurrentUserDTO();
        return ResponseEntity.ok(
                BaseResponseDTO.success("Product Updated Successful", currentUser));
    }

    @PutMapping("/{id}/profile")
    @PreAuthorize("hasRole('ADMIN') or #id == authentication.principal.id")
    public ResponseEntity<BaseResponseDTO<UserDTO>> updateUserProfile(
            @PathVariable long id,
            @Valid @RequestBody UserDTO userDTO) {
        UserDTO updatedUser = userService.updateUserProfile(id, userDTO);
        return ResponseEntity.ok(BaseResponseDTO.success("User Profile Updated Successfully", updatedUser));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<BaseResponseDTO<Void>> deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return ResponseEntity.ok(BaseResponseDTO.success("User Deleted Successfully", null));
    }

    @GetMapping("/search")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<BaseResponseDTO<Page<UserDTO>>> searchUser(
            @RequestParam String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "15") int size) {

        Pageable pageable = PageRequest.of(page, size);
                Page<UserDTO> users = userService.searchUsers(keyword, pageable);
                return ResponseEntity.ok(BaseResponseDTO.success(users));
    }

    @GetMapping("/role/{role}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<BaseResponseDTO<Page<UserDTO>>> getUsersByRole(
            @RequestParam String role,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "15") int size) {

        Pageable pageable = PageRequest.of(page, size);
        Page<UserDTO> users = userService.getUsersByRole(role, pageable);
        return ResponseEntity.ok(BaseResponseDTO.success(users));
    }

    @GetMapping("/debug/roles")
    @PreAuthorize("isAuthenticated()")
    public List<String> debugRoles(Authentication auth) {
        return auth.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .toList();
    }
}


