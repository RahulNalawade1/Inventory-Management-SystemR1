package com.inventorystockmanagement.Controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import com.inventorystockmanagement.Dtos.BaseResponseDTO;
import com.inventorystockmanagement.Dtos.ProductDTO;
import com.inventorystockmanagement.Dtos.StockUpdateDTO;
import com.inventorystockmanagement.Services.ProductService;

import java.math.BigDecimal;
import java.util.List;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/products")
@RequiredArgsConstructor
public class ProductController {

    private final ProductService productService;

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<BaseResponseDTO<?>> createProduct(@Valid @RequestBody ProductDTO productDTO) {
        try {
            ProductDTO createdProduct = productService.createProduct(productDTO);
            return ResponseEntity.ok(BaseResponseDTO.success("Product created successfully", createdProduct));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(BaseResponseDTO.error(e.getMessage()));
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<BaseResponseDTO<?>> getProductById(@PathVariable Long id) {
        try {
            ProductDTO product = productService.getProductById(id);
            return ResponseEntity.ok(BaseResponseDTO.success("Product retrieved successfully", product));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(BaseResponseDTO.error(e.getMessage()));
        }
    }

    @GetMapping
    public ResponseEntity<BaseResponseDTO<?>> getAllProducts(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDirection) {

        try {
            Sort sort = sortDirection.equalsIgnoreCase("desc") ?
                    Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
            Pageable pageable = PageRequest.of(page, size, sort);

            Page<ProductDTO> products = productService.getAllProducts(pageable);
            return ResponseEntity.ok(BaseResponseDTO.success("Products retrieved successfully", products));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(BaseResponseDTO.error(e.getMessage()));
        }
    }

    @GetMapping("/category/{category}")
    public ResponseEntity<BaseResponseDTO<?>> getProductsByCategory(
            @PathVariable String category,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        try {
            Pageable pageable = PageRequest.of(page, size);
            Page<ProductDTO> products = productService.getProductsByCategory(category, pageable);
            return ResponseEntity.ok(BaseResponseDTO.success("Products retrieved successfully", products));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(BaseResponseDTO.error(e.getMessage()));
        }
    }

    @GetMapping("/search")
    public ResponseEntity<BaseResponseDTO<?>> searchProducts(
            @RequestParam String name,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        try {
            Pageable pageable = PageRequest.of(page, size);
            Page<ProductDTO> products = productService.searchProducts(name, pageable);
            return ResponseEntity.ok(BaseResponseDTO.success("Products retrieved successfully", products));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(BaseResponseDTO.error(e.getMessage()));
        }
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<BaseResponseDTO<?>> updateProduct(@PathVariable Long id, @Valid @RequestBody ProductDTO productDTO) {
        try {
            ProductDTO updatedProduct = productService.updateProduct(id, productDTO);
            return ResponseEntity.ok(BaseResponseDTO.success("Product updated successfully", updatedProduct));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(BaseResponseDTO.error(e.getMessage()));
        }
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<BaseResponseDTO<?>> deleteProduct(@PathVariable Long id) {
        try {
            productService.deleteProduct(id);
            return ResponseEntity.ok(BaseResponseDTO.success("Product Deleted Successfully", null));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(BaseResponseDTO.error(e.getMessage()));
        }
    }

    @PatchMapping("/{id}/stock")
    @PreAuthorize("hasRole('DEALER') or hasRole('ADMIN')")
    public ResponseEntity<BaseResponseDTO<?>> updateStock(
            @PathVariable Long id,
            @Valid @RequestBody StockUpdateDTO stockUpdateDTO,
            Authentication authentication) {

        try {
           
            Long userId = 1L;
            ProductDTO updatedProduct = productService.updateStock(id, stockUpdateDTO, userId);
            return ResponseEntity.ok(BaseResponseDTO.success("Stock Updated successfully", updatedProduct));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(BaseResponseDTO.error(e.getMessage()));
        }
    }
    

    @GetMapping("/low-stock")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<BaseResponseDTO<?>> getLowStockProducts() {
        try {
            List<ProductDTO> lowStockProducts = productService.getLowStockProducts();
            return ResponseEntity.ok(BaseResponseDTO.success("Low stock products retrieved successfully", lowStockProducts));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(BaseResponseDTO.error(e.getMessage()));
        }
    }
}

