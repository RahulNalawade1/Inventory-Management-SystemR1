package com.inventorystockmanagement.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.inventorystockmanagement.Entities.TransactionLog;

import java.util.List;

@Repository
public interface TransactionLogRepository extends JpaRepository<TransactionLog, Long> {
    List<TransactionLog> findByProductIdOrderByCreatedAtDesc(Long productId);
}
