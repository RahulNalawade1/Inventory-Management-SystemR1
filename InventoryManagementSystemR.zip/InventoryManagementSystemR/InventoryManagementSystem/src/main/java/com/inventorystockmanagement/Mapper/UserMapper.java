package com.inventorystockmanagement.Mapper;

import com.inventorystockmanagement.Enums.UserStatus;
import org.springframework.stereotype.Component;

import com.inventorystockmanagement.Dtos.UserDTO;
import com.inventorystockmanagement.Entities.User;

@Component
public class UserMapper {

    public UserDTO toDTO(User user) {
        if (user == null) {
            return null;
        }
        UserDTO userDTO = new UserDTO();
        userDTO.setId(user.getId());
        userDTO.setName(user.getName());
        userDTO.setEmail(user.getEmail());
        userDTO.setRole(user.getRole());
        userDTO.setMobileNo(user.getMobileNo());
        userDTO.setAddress(user.getAddress());
        userDTO.setCreatedAt(user.getCreatedAt());

        if (user.getStatus() != null) {
            userDTO.setStatus(user.getStatus().name());
        }
        else {
            userDTO.setStatus("ACTIVE");
        }

        return userDTO;
    }

    public User toEntity(UserDTO userDTO) {
        if (userDTO == null) {
            return null;
        }

        User user = new User();
        user.setId(userDTO.getId());
        user.setName(userDTO.getName());
        user.setEmail(userDTO.getEmail());
        user.setRole(userDTO.getRole());
        user.setMobileNo(userDTO.getMobileNo());
        user.setAddress(userDTO.getAddress());

        if (userDTO.getStatus() != null) {
            user.setStatus(UserStatus.valueOf(userDTO.getStatus()));
        } else {
            user.setStatus(UserStatus.ACTIVE);
        }

        return user;
    }
}
