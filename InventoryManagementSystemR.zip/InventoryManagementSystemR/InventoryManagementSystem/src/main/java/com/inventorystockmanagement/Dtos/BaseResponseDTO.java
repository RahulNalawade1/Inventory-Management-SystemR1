package com.inventorystockmanagement.Dtos;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class BaseResponseDTO<T> {
    private String status;
    private String message;
    private T data;
    private LocalDateTime timestamp = LocalDateTime.now();

    public BaseResponseDTO() {
        this.timestamp = LocalDateTime.now();
    }
    public static <T> BaseResponseDTO<T> success(T data) {
        BaseResponseDTO<T> response = new BaseResponseDTO<>();
        response.setStatus("SUCCESS");
        response.setMessage("Operation Completed successfully");
        response.setData(data);
        return response;
    }

    public static <T> BaseResponseDTO<T> success(String message, T data) {
        BaseResponseDTO<T> response = new BaseResponseDTO<>();
        response.setStatus("SUCCESS");
        response.setMessage(message);
        response.setData(data);
        return response;
    }

    public static <T> BaseResponseDTO<T> error(String message) {
        BaseResponseDTO<T> response = new BaseResponseDTO<>();
        response.setStatus("ERROR");
        response.setMessage(message);
        return response;
    }
}

