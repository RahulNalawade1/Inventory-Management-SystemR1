package com.inventorystockmanagement.Dtos;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RegisterRequestDTO {

    @NotBlank
    private String name;

    @NotBlank
    @Email
    private String email;

    @NotBlank
    private String password;

    @NotBlank
    private String role;

    private String mobileNo;
    private String address;

    private String dealerCode;

    @JsonProperty("business_name")
    private String businessName;

    @JsonProperty("tax_number")
    private String taxNumber;

    @JsonProperty("business_address")
    private String businessAddress;

    private String customerCode;
    private String dateOfBirth;
    private String shippingAddress;

    private String preferredPaymentMethod;

    private String adminCode;
    }
