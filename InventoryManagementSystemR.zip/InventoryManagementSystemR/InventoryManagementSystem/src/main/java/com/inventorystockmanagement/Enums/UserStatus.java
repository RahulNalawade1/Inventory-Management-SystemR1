package com.inventorystockmanagement.Enums;

public enum UserStatus {
   ACTIVE,
    INACTIVE
}
