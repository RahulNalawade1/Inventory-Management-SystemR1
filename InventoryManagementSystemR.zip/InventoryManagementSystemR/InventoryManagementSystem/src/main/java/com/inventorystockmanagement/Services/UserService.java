package com.inventorystockmanagement.Services;

import com.inventorystockmanagement.Dtos.LoginRequestDTO;
import com.inventorystockmanagement.Dtos.LoginResponseDTO;
import com.inventorystockmanagement.Dtos.RegisterRequestDTO;
import com.inventorystockmanagement.Dtos.UserDTO;
import com.inventorystockmanagement.Entities.Role;
import com.inventorystockmanagement.Entities.User;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface UserService {

    UserDTO registerUser(RegisterRequestDTO registerRequestDTO);
    LoginResponseDTO loginUser(LoginRequestDTO loginRequestDTO);
    UserDTO getUserById(Long id);
    UserDTO getUserByEmail(String email);
    User getCurrentUser();
    UserDTO getCurrentUserDTO();
    UserDTO updateUserProfile(long id, @Valid UserDTO userDTO);
    void deleteUser(Long id);
    Page<UserDTO> searchUsers(String keyword, Pageable pageable);
    Page<UserDTO> getUsersByRole(String role, Pageable pageable);
    Page<UserDTO> getAllUsers(Pageable pageable);
}
