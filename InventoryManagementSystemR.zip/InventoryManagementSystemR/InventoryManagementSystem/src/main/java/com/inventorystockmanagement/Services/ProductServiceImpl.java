package com.inventorystockmanagement.Services;

import com.inventorystockmanagement.Repositories.RoleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.inventorystockmanagement.Dtos.ProductDTO;
import com.inventorystockmanagement.Dtos.StockUpdateDTO;
import com.inventorystockmanagement.Entities.Product;
import com.inventorystockmanagement.Entities.TransactionLog;
import com.inventorystockmanagement.Exceptions.ResourceNotFoundException;
import com.inventorystockmanagement.Mapper.ProductMapper;
import com.inventorystockmanagement.Repositories.ProductRepository;
import com.inventorystockmanagement.Repositories.TransactionLogRepository;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService {

    @Autowired
    private final ProductRepository productRepository;

    @Autowired
    private final TransactionLogRepository transactionLogRepository;

    @Autowired
    private final ProductMapper productMapper;

    @Autowired
    private final RoleRepository roleRepository;

    @Override
    @Transactional
    public ProductDTO createProduct(ProductDTO productDTO) {
        Product product = productMapper.toEntity(productDTO);
        Product savedProduct = productRepository.save(product);
        return productMapper.toDTO(savedProduct);
    }

    @Override
    public ProductDTO getProductById(Long id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + id));
        return productMapper.toDTO(product);
    }

    @Override
    public Page<ProductDTO> getAllProducts(Pageable pageable) {
        return productRepository.findAll(pageable)
                .map(productMapper::toDTO);
    }

    @Override
    public Page<ProductDTO> getProductsByCategory(String category, Pageable pageable) {
        return productRepository.findByCategory(category, pageable)
                .map(productMapper::toDTO);
    }

    @Override
    public Page<ProductDTO> getProductsByBrand(String brand, Pageable pageable) {
        return productRepository.findByBrand(brand, pageable)
                .map(productMapper::toDTO);
    }

    @Override
    public Page<ProductDTO> getProductsByPriceRange(BigDecimal minPrice, BigDecimal maxPrice, Pageable pageable) {
        return productRepository.findByPriceRange(minPrice, maxPrice, pageable)
                .map(productMapper::toDTO);
    }

    @Override
    public Page<ProductDTO> searchProducts(String name, Pageable pageable) {
        return productRepository.findByNameContainingIgnoreCase(name, pageable)
                .map(productMapper::toDTO);
    }

    @Override
    @Transactional
    public ProductDTO updateProduct(Long id, ProductDTO productDTO) {
        Product existingProduct = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + id));

        existingProduct.setName(productDTO.getName());
        existingProduct.setCategory(productDTO.getCategory());
        existingProduct.setBrand(productDTO.getBrand());
        existingProduct.setDescription(productDTO.getDescription());
        existingProduct.setPrice(productDTO.getPrice());
        existingProduct.setMinStockLevel(productDTO.getMinStockLevel());

        Product updatedProduct = productRepository.save(existingProduct);
        return productMapper.toDTO(updatedProduct);
    }

    @Override
    @Transactional
    public void deleteProduct(Long id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + id));
        productRepository.delete(product);
    }

    @Override
    @Transactional
    public ProductDTO updateStock(Long id, StockUpdateDTO stockUpdateDTO, Long userId) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + id));

        int previousQuantity = product.getQuantity();
        int newQuantity;

        if ("DECREASE".equalsIgnoreCase(stockUpdateDTO.getChangeType())) {
            newQuantity = previousQuantity - stockUpdateDTO.getQuantity();
            if (newQuantity < 0) {
                throw new RuntimeException("Insufficient stock available");
            }
        } else {

            newQuantity = previousQuantity + stockUpdateDTO.getQuantity();
        }

        product.setQuantity(newQuantity);
        Product updatedProduct = productRepository.save(product);

        TransactionLog transactionLog = new TransactionLog();
        transactionLog.setProductId(id);
        transactionLog.setUserId(userId);
        transactionLog.setChangeType(stockUpdateDTO.getChangeType());
        transactionLog.setQuantityChanged(stockUpdateDTO.getQuantity());
        transactionLog.setPreviousQuantity(previousQuantity);
        transactionLog.setNewQuantity(newQuantity);
        transactionLogRepository.save(transactionLog);

        return productMapper.toDTO(updatedProduct);
    }

    @Override
    public List<ProductDTO> getLowStockProducts() {
        return productRepository.findLowStockProducts()
                .stream()
                .map(productMapper::toDTO)
                .collect(Collectors.toList());
    }
}

