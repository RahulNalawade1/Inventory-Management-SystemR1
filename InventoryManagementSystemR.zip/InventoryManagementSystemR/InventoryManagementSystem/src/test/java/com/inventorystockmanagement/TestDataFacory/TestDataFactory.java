package com.inventorystockmanagement.TestDataFacory;

import com.inventorystockmanagement.Dtos.RegisterRequestDTO;
import com.inventorystockmanagement.Entities.*;
import com.inventorystockmanagement.Enums.UserStatus;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class TestDataFactory {

    public static User createUser(Long id, String name, String email, Role role) {

        User user = new User();
        user.setId(id);
        user.setName(name);
        user.setEmail(email);
        user.setPassword("");
        user.setRole("Customer");
        user.setMobileNo("1234567890");
        user.setAddress("Test Address");
        user.setStatus(UserStatus.ACTIVE);
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());

        return user;
    }

    //Product Related Data Test
    public static Product createProduct(Long id, String name, String category, String brand, BigDecimal price, Integer quantity, Integer minStockLevel) {
        Product product = new Product();
        product.setId(id);
        product.setName(name);
        product.setCategory(category);
        product.setBrand(brand);
        product.setDescription("Text Description for " + name);
        product.setPrice(price);
        product.setQuantity(quantity);
        product.setMinStockLevel(minStockLevel);
        product.setCreatedAt(LocalDateTime.now());
        product.setUpdatedAt(LocalDateTime.now());
        return product;
    }

    public static Product createLaptopProduct() {
        return createProduct(1L, "Dell XPS 13 Laptop", "Electronics",
                "Dell", new BigDecimal("1298.99"), 25, 5);
    }

    public static Product createPhoneProduct() {
        return createProduct(2L, "I Phone 17 Pro Max", "Electronics",
                "Apple", new BigDecimal("999.99"), 15, 5);
    }

    public static Product createLowStockProduct() {
        return createProduct(3L, "Low Stock Item", "Electronics",
                "Test Brand", new BigDecimal("99.99"),2, 10);
    }

    public static Product createOutStockProduct() {
        return createProduct(4L, "Out Of Stock Item", "Electronics",
                "Test Brand", new BigDecimal("49.99"),0, 5);
    }

    // DTO test Data
    public static RegisterRequestDTO createRegisterRequestDTO() {
        RegisterRequestDTO dto = new RegisterRequestDTO();

        dto.setName("New Test User");
        dto.setEmail("newuser@gmail.com");
        dto.setPassword("password123");
        dto.setCustomerCode("01");
        dto.setMobileNo("0987654321");
        dto.setAddress("New Test Address");
        return dto;
    }

}
