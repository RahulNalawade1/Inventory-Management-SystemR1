package com.inventorystockmanagement.impl;

import com.inventorystockmanagement.Dtos.LoginRequestDTO;
import com.inventorystockmanagement.Dtos.RegisterRequestDTO;
import com.inventorystockmanagement.Entities.User;
import com.inventorystockmanagement.Exceptions.ResourceNotFoundException;
import com.inventorystockmanagement.Repositories.UserRepository;
import com.inventorystockmanagement.Services.UserServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.hibernate.validator.internal.util.Contracts.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class UserServiceImplTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private UserServiceImpl userService;


    @Test
    void testRegisterUser_Success() {
        RegisterRequestDTO request = new RegisterRequestDTO();
        request.setEmail("test@gmail.com");
        request.setPassword("1234567890");
        
        when(userRepository.existsByEmail("test@gmail.com")).thenReturn(false);
        when(passwordEncoder.encode("password123")).thenReturn("encodedPass");

        var result = userService.registerUser(request);

        assertNotNull(result);
        verify(userRepository).save(any(User.class));

    }

    @Test
    void testRegisterUser_EmailExists() {
        RegisterRequestDTO request = new RegisterRequestDTO();
        request.setEmail("test@gamil.com");
        when(userRepository.existsByEmail("test@gamil.com")).thenReturn(true);

        assertThrows(RuntimeException.class, () -> userService.registerUser(request));
    }

    @Test
    void testLogin_Success() {
        LoginRequestDTO request = new LoginRequestDTO();
        request.setEmail("test@gmail.com");
        request.setPassword("1234567890");

        when(userRepository.findByEmail("test@gmail.com"))
                .thenReturn(Optional.of(new User()));

        assertThrows(RuntimeException.class, () -> userService.loginUser(request)); //login
    }

    @Test
    void testGetUserById_Found() {
        Long userId = 1L;
        when(userRepository.findById(userId)).thenReturn(Optional.of(new User()));

        var result = userService.getUserById(userId);
        assertNotNull(result);
    }

    @Test
    void testGetUserById_NotFound() {
        Long userId = 999L;
        when(userRepository.findById(userId)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> userService.getUserById(userId));
    }
}
