package com.inventorystockmanagement.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.Optional;

import com.inventorystockmanagement.Mapper.ProductMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import com.inventorystockmanagement.Dtos.ProductDTO;
import com.inventorystockmanagement.Entities.Product;
import com.inventorystockmanagement.Exceptions.ResourceNotFoundException;
import com.inventorystockmanagement.Repositories.ProductRepository;
import com.inventorystockmanagement.Services.ProductServiceImpl;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class ProductServiceImplTest {

    @Mock
    private ProductRepository productRepository;

    @Mock
    private ProductMapper productMapper;

    @InjectMocks
    private ProductServiceImpl productService;

    private Product sampleProduct;

    @BeforeEach
    void setUp() {
        sampleProduct = new Product();
        sampleProduct.setId(1L);
        sampleProduct.setName("Test Product");
        sampleProduct.setQuantity(10);
        sampleProduct.setPrice(BigDecimal.valueOf(89.99));

    }
    
    @Test
    void shouldReturnProduct_WhenProductExists() {

        when(productRepository.findById(1L)).thenReturn(Optional.of(sampleProduct));
        ProductDTO result = productService.getProductById(1L);

        assertNotNull(result);
        assertEquals("Test Product", result.getName());
        verify(productRepository, times(1)).findById(1L);

    }

    @Test
    void shouldThrowException_WhenProductNotFound() {
        long productId = 999L;
        when(productRepository.findById(productId)).thenReturn(Optional.empty());

        ResourceNotFoundException exception = assertThrows(ResourceNotFoundException.class,
                () -> productService.getProductById(productId));



        assertTrue(exception.getMessage().replaceAll("\\s+", "")
                .equalsIgnoreCase("Productnotfoundwithid:999"));
        verify(productRepository, times(1)).findById(productId);
    }



    @Test
    void shouldDeleteProductSuccessfully() {
        // Arrange
        long productId = 1L;
        when(productRepository.findById(productId)).thenReturn(Optional.of(sampleProduct));
        doNothing().when(productRepository).delete(sampleProduct);

        // Art
        productService.deleteProduct(productId);

        // Assert

        verify(productRepository, times(1)).findById(productId);
        verify(productRepository, times(1)).delete(sampleProduct);
    }


}

